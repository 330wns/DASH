#region 기본설정
기숙사_이름 = 'Birch'
스프레드시트_키 = '1C25oe0qBzFWiP9sY1hJ5x_nSJw-wPp6ej9ZPgY19LV8'
JSON파일_경로 = 'service_account.json'
리더기_사용 = False #PC/SC 리더기 사용시 True
디버그_모드 = False #상세한 로그 모드. 웬만하면 일반 사용자는 사용 안해도 됌.
#endregion

#region 로깅시트
로깅시트사용 = True
로깅시트_이름 = '출입 기록 로그'
로깅시트_가로열 = '26'  
로깅시트_세로열 = '30000'
#endregion

"""%time : 현재 시간 (HH:MM:SS) / %date : 현재 날짜 (YYYY-MM-DD) / %name : 태깅한 이름 / %id : 태깅한 카드 번호"""
#region 음성출력
음성출력 = True
음성출력_배속 = 2 # 2배속이 기본
음성출력_언어 = 'ko'
음성출력_메세지_출입 = '%name 학생, 안녕하세요!'
음성출력_메세지_외출 = '%name 학생, 안녕히가세요!'
음성출력_없는정보 = '등록되지 않은 정보입니다.'
#endregion

#region 터미널출력
터미널출력_메세지_출입 = '%name 학생, 안녕하세요!'
터미널출력_메세지_외출 = '%name 학생, 안녕히가세요!'
터미널출력_없는정보 = '등록되지 않은 정보입니다.'
#endregion

#region 지챗전송
지챗전송 = False
지챗_웹훅_링크 = ['https://chat.googleapis.com/v1/spaces/AAQAENhp5nQ/messages?key=AIzaSyDdI0hCZtE6vySjMm-WEfRq3CPzqKqqsHI&token=ogkrT5G3HtV4XnQeSqPEEQ_GviQYk3a0KdbgH0GNZ_k','https://chat.googleapis.com/v1/spaces/AAQAENhp5nQ/messages?key=AIzaSyDdI0hCZtE6vySjMm-WEfRq3CPzqKqqsHI&token=HZOW4d7O7BX2AkuZVoU-UPziKQF3s3lc7lRxiGUpLG0','https://chat.googleapis.com/v1/spaces/AAQAENhp5nQ/messages?key=AIzaSyDdI0hCZtE6vySjMm-WEfRq3CPzqKqqsHI&token=YO0EgGiuvIqxflr1D60MrifMpBsnND861GwfcixeAZk'] # 여러개 설정 가능
지챗_출입메세지 = '👋 %name 학생, 출입했습니다.\n⏰ %date %time'
지챗_외출메세지 = '👋 %name 학생, 외출했습니다.\n⏰ %date %time'
지챗_없는정보메세지 = '등록되지 않은 카드 사용 시도!\n(ID : %id)'
지챗_재전송시도 = True
지챗_재전송멈춤시간 = 1 # 초단위
지챗_재전송시도횟수 = 5
#endregion

import base64;exec(base64.b64decode("cHJpbnQoJ3NldHRpbmdzLnB564qUIOyEpOygleyaqSDtjIzsnbzsnoXri4jri6QhIOyLpO2Wie2VoCDtlYTsmpTqsIAg7JeG7Iq164uI64ukIScpIGlmIF9fbmFtZV9fID09ICdfX21haW5fXycgZWxzZSBOb25l"))